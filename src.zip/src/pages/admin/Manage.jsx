import React from "react";
import TableUsers from "../../components/admin/TableUsers";

const Manage = () => {
  return (
    <div>
      <TableUsers />
    </div>
  );
};

export default Manage;
