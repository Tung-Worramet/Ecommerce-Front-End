import React from "react";
import TableOrders from "../../components/admin/TableOrders";

const ManageOrders = () => {
  return (
    <div>
      <TableOrders />
    </div>
  );
};

export default ManageOrders;
