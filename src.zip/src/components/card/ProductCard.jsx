import React from "react";
import { ShoppingCart } from "lucide-react";
import useEcomStore from "../../store/ecom-store";
import { numberFormat } from "../../utils/number";
import { motion } from "framer-motion";

// item นี้มาจากหน้า Shop , item ใน ({ item }) มาจาก item ตัวแรกที่ไม่ได้อยู่ใน {} item={item}
const ProductCard = ({ item }) => {
  const actionAddtoCart = useEcomStore((state) => state.actionAddtoCart);

  return (
    // <motion.div
    //   initial={{ opacity: 0, y: 20 }}
    //   animate={{ opacity: 1, y: 0 }}
    //   transition={{ duration: 0.5, ease: "easeOut" }}
    //   className="bg-white rounded-xl shadow-lg overflow-hidden w-full sm:w-60 md:w-64 lg:w-72 transition-transform duration-200 hover:scale-105"
    // >
    //   {/* 🔹 ภาพสินค้า */}
    //   <div className="relative overflow-hidden group">
    //     {item.images && item.images.length > 0 ? (
    //       <img
    //         src={item.images[0].url}
    //         className="w-full h-56 object-cover transition-transform duration-300 group-hover:scale-110"
    //         alt={item.title}
    //       />
    //     ) : (
    //       <div className="w-full h-56 bg-gray-200 flex items-center justify-center text-gray-500 text-lg font-semibold">
    //         No Image
    //       </div>
    //     )}
    //   </div>

    //   {/* 🔹 รายละเอียดสินค้า */}
    //   <div className="p-4">
    //     <h3 className="text-lg font-semibold text-gray-800 truncate">
    //       {item.title}
    //     </h3>
    //     <p className="text-sm text-gray-500 truncate">{item.description}</p>

    //     {/* 🔹 ราคา และปุ่ม Add to Cart */}
    //     <div className="flex justify-between items-center mt-4">
    //       <span className="text-lg font-bold text-blue-600">
    //         {numberFormat(item.price)}
    //       </span>
    //       <motion.button
    //         onClick={() => actionAddtoCart(item)}
    //         whileTap={{ scale: 0.9 }}
    //         className="bg-blue-500 text-white p-2 rounded-lg shadow-md hover:bg-blue-700 transition"
    //       >
    //         <ShoppingCart className="w-5 h-5" />
    //       </motion.button>
    //     </div>
    //   </div>
    // </motion.div>

    // โค้ดเก่า
    <motion.div
      initial={{ opacity: 0, scale: 0.5 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="border rounded-md shadow-md p-2 w-48">
        <div>
          {item.images && item.images.length > 0 ? (
            <img
              src={item.images[0].url}
              className="rounded-md shadow-md w-full h-60 object-cover hover:scale-110 hover:duration-200"
            />
          ) : (
            <div className="w-full h-60 bg-gray-300 rounded-md text-center flex items-center justify-center shadow">
              No Image
            </div>
          )}
        </div>

        <div className="py-2">
          <p className="text-xl truncate">{item.title}</p>
          <p className="text-sm text-gray-500 truncate">{item.description}</p>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-xl font-bold">{numberFormat(item.price)}</span>
          <button
            onClick={() => actionAddtoCart(item)}
            className="bg-blue-500 rounded-md p-2 hover:bg-blue-700 shadow-md transition-all hover:scale-105"
          >
            <ShoppingCart />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;
