import React from "react";

const HomeUser = () => {
  return <div>HomeUser</div>;
};

export default HomeUser;
