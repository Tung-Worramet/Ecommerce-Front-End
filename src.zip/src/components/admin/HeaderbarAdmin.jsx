import React from "react";

const HeaderbarAdmin = () => {
  return (
    <header className="bg-red-400 h-16 flex items-center px-6">Header</header>
  );
};

export default HeaderbarAdmin;
