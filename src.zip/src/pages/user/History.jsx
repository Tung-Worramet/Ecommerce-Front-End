import React from "react";
import HistoryCard from "../../components/card/HistoryCard";

const History = () => {
  return (
    <div>
      <HistoryCard />
    </div>
  );
};

export default History;
