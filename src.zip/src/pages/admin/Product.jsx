import React from "react";
import FormProduct from "../../components/admin/FormProduct";

const Product = () => {
  return (
    <div>
      <FormProduct />
    </div>
  );
};

export default Product;
