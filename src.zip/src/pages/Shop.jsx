import React, { useEffect } from "react";
import ProductCard from "../components/card/ProductCard";
import useEcomStore from "../store/ecom-store";
import SearchCard from "../components/card/SearchCard";
import CartCard from "../components/card/CartCard";
import { motion } from "framer-motion";

const Shop = () => {
  const getProduct = useEcomStore((state) => state.getProduct);
  const products = useEcomStore((state) => state.products);

  useEffect(() => {
    getProduct();
  }, []);

  return (
    // <motion.div
    //   initial={{ opacity: 0, y: 20 }}
    //   animate={{ opacity: 1, y: 0 }}
    //   transition={{ duration: 0.5, ease: "easeOut" }}
    //   className="flex flex-col md:flex-row min-h-screen bg-gray-100"
    // >
    //   {/* 🔹 Sidebar ค้นหา */}
    //   <motion.div
    //     initial={{ x: -20, opacity: 0 }}
    //     animate={{ x: 0, opacity: 1 }}
    //     transition={{ duration: 0.5 }}
    //     className="md:w-1/4 flex justify-center md:h-1/4 "
    //   >
    //     <SearchCard />
    //   </motion.div>

    //   {/* 🔹 ส่วนแสดงสินค้า */}
    //   <div className="md:w-1/2 w-full p-6">
    //     <h1 className="text-2xl font-bold mb-4 text-gray-900">
    //       🛍️ สินค้าทั้งหมด
    //     </h1>
    //     <motion.div
    //       initial={{ opacity: 0 }}
    //       animate={{ opacity: 1 }}
    //       transition={{ duration: 0.5 }}
    //       className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
    //     >
    //       {products.length > 0 ? (
    //         products.map((item, index) => (
    //           <ProductCard key={index} item={item} />
    //         ))
    //       ) : (
    //         <p className="text-center text-gray-500 col-span-3">
    //           📦 ไม่มีสินค้าในขณะนี้
    //         </p>
    //       )}
    //     </motion.div>
    //   </div>

    //   {/* 🔹 Sidebar ตะกร้าสินค้า */}
    //   <motion.div
    //     initial={{ x: 20, opacity: 0 }}
    //     animate={{ x: 0, opacity: 1 }}
    //     transition={{ duration: 0.5 }}
    //     className="md:w-1/4 w-full p-4 bg-gray-100 md:h-screen overflow-y-auto "
    //   >
    //     <CartCard />
    //   </motion.div>
    // </motion.div>

    // โค้ดเก่า
    <div className="flex">
      {/* SearchBar */}
      <div className="w-1/4 p-4 bg-gray-100 h-screen">
        <SearchCard />
      </div>

      {/* Product */}
      <div className="w-1/2 p-4 h-screen overscroll-y-auto">
        <p className="text-2xl font-bold md-4">สินค้าทั้งหมด</p>
        <div className="flex flex-wrap gap-4">
          {/* Product Card */}
          {products.map((item, index) => (
            <ProductCard key={index} item={item} />
          ))}

          {/* Product Card */}
        </div>
      </div>

      {/* Cart */}
      <div className="w-1/4 p-4 bg-gray-100 h-screen overscroll-y-auto">
        <CartCard />
      </div>
    </div>
  );
};

export default Shop;
